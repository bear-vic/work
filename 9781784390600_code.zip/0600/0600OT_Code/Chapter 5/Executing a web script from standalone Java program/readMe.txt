For InvokeWebScript class, 
add following jars in the build path.
1.commons-httpclient-3.1.jar
2.commons-logging-1.1.jar
3.commons-codec-1.3.jar