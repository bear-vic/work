model.foldernode = companyhome.childByNamePath("Guest Home");	
