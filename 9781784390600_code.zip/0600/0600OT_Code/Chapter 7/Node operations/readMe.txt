Description - 
It covers the code details for below sections.
Find a node, 
Check user permission on a node,
Get path of node
Get property of a node
Log the property value
Modify property of node
Get current user�s name & email

Deploy - 
Deploy the 3 files at tomcat\shared\classes\alfresco\extension\templates\webscripts\example inside your alfresco installed directory.

Register the webscript
http://localhost:8080/alfresco/service/index
Click on Refresh Web Scripts

Invoke webscript
http://localhost:8080/alfresco/service/example/nodeinaction?nodeid=yournodeid