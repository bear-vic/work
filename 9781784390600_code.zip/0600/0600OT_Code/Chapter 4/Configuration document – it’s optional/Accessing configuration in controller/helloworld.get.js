model.email="Ramesh.chauhan@cignex.com";

var env = new XML(config.script);
logger.log(env.envname);